﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WEB_API_Student.Tools
{
    public class jSonTools
    {
        public static List<T> ExtractListFromString<T>(string jSonString, string SerachString)
        {
            return (null);
        }
    }
}